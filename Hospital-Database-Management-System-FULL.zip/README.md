# Hospital Database Management System (DBMS Project)

A complete relational database system designed to manage hospital operations such as patient records, doctor schedules, appointments, admissions, billing, prescriptions, and medical history. Built using **MySQL**, with a fully normalized schema, constraints, triggers, sample data, and analytical SQL queries.

## 📂 Project Structure
```
Hospital-Database-Management-System/
│
├── schema/
│   └── hospital_schema.sql
│
├── data/
│   └── sample_data.sql
│
├── queries/
│   └── analytics.sql
│
├── triggers/
│   └── hospital_triggers.sql
│
└── procedures/
    └── hospital_procedures.sql
```

## 📊 ER Diagram (Text Overview)
```
Departments (DepartmentID PK)
    └── Doctors (DoctorID PK, DepartmentID FK)
            └── Appointments (AppointmentID PK, DoctorID FK, PatientID FK)

Patients (PatientID PK)
    ├── Appointments
    ├── Admissions
    ├── MedicalRecords
    └── Billing

MedicalRecords (RecordID PK)
    └── Prescriptions (PrescriptionID PK)
```
