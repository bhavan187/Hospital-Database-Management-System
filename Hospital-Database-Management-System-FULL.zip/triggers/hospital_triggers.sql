CREATE TRIGGER generate_bill_on_discharge
AFTER UPDATE ON Admissions
FOR EACH ROW
BEGIN
    IF NEW.DischargeDate IS NOT NULL THEN
        INSERT INTO Billing (PatientID, BillDate, TotalAmount, AmountPaid)
        VALUES (NEW.PatientID, NEW.DischargeDate, 5000, 0);
    END IF;
END;

CREATE TRIGGER prevent_negative_payment
BEFORE INSERT ON Billing
FOR EACH ROW
BEGIN
    IF NEW.AmountPaid < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Amount paid cannot be negative';
    END IF;
END;
