DELIMITER $$

CREATE PROCEDURE GetPatientHistory(IN pid INT)
BEGIN
    SELECT * FROM Appointments WHERE PatientID = pid;
    SELECT * FROM MedicalRecords WHERE PatientID = pid;
    SELECT * FROM Billing WHERE PatientID = pid;
END $$

DELIMITER ;
