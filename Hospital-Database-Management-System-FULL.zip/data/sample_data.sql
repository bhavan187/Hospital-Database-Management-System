INSERT INTO Departments (DepartmentName, Location) VALUES
('Cardiology', 'Block A'),
('Neurology', 'Block B'),
('Orthopedics', 'Block C');

INSERT INTO Doctors (DoctorName, Specialization, Phone, DepartmentID) VALUES
('Dr. Smith', 'Cardiologist', '9876543210', 1),
('Dr. John', 'Neurologist', '9876543211', 2),
('Dr. Annie', 'Orthopedic Surgeon', '9876543212', 3);

INSERT INTO Patients (Name, Age, Gender, Address, Phone) VALUES
('Rahul Kumar', 35, 'Male', 'Mysore', '9012345678'),
('Sneha R', 28, 'Female', 'Bangalore', '9098765432');

INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate, Reason, Status) VALUES
(1, 1, '2025-12-10', 'Chest pain', 'Scheduled'),
(2, 2, '2025-12-12', 'Migraine', 'Scheduled');

INSERT INTO Admissions (PatientID, AdmitDate, DischargeDate, RoomNumber) VALUES
(1, '2025-12-01', '2025-12-05', 'A101');

INSERT INTO MedicalRecords (PatientID, Diagnosis, Treatment, RecordDate) VALUES
(1, 'Hypertension', 'Medication', '2025-12-02');

INSERT INTO Prescriptions (RecordID, MedicineName, Dosage, Duration) VALUES
(1, 'Amlodipine', '5mg', '30 days');

INSERT INTO Billing (PatientID, BillDate, TotalAmount, AmountPaid) VALUES
(1, '2025-12-05', 6000, 4000);
