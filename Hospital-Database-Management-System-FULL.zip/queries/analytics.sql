-- Upcoming Appointments
SELECT p.PatientID, p.Name, a.AppointmentDate, d.DoctorName, d.Specialization
FROM Appointments a
JOIN Patients p ON a.PatientID = p.PatientID
JOIN Doctors d ON a.DoctorID = d.DoctorID
WHERE a.AppointmentDate >= CURDATE()
ORDER BY a.AppointmentDate;

-- Top Diagnosed Diseases
SELECT Diagnosis, COUNT(*) AS Frequency
FROM MedicalRecords
GROUP BY Diagnosis
ORDER BY Frequency DESC;

-- Revenue Per Month
SELECT DATE_FORMAT(BillDate, '%Y-%m') AS Month, SUM(TotalAmount) AS Revenue
FROM Billing
GROUP BY Month;

-- Patients with Unpaid Bills
SELECT p.Name, b.TotalAmount, b.AmountPaid
FROM Billing b
JOIN Patients p ON p.PatientID = b.PatientID
WHERE b.AmountPaid < b.TotalAmount;
